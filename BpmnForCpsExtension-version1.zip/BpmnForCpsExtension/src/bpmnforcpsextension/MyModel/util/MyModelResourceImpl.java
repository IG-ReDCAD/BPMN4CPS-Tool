/**
 */
package bpmnforcpsextension.MyModel.util;

import org.eclipse.emf.common.util.URI;

import org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource </b> associated with the package.
 * <!-- end-user-doc -->
 * @see bpmnforcpsextension.MyModel.util.MyModelResourceFactoryImpl
 * @generated
 */
public class MyModelResourceImpl extends XMLResourceImpl {
	/**
	 * Creates an instance of the resource.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param uri the URI of the new resource.
	 * @generated
	 */
	public MyModelResourceImpl(URI uri) {
		super(uri);
	}

} //MyModelResourceImpl
